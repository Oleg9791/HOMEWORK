<?php
$fileName = "opros.txt";
$separator = " - ";
