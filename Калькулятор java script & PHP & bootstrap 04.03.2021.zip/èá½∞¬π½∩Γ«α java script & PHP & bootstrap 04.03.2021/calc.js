//calc.js
function f() {
    alert('Привет')
}
