<?php
include "../vendor/autoload.php";
$config = [
    "servername" => "localhost",
    "username" => "root",
    "password" => "root",
    "dbname" => "guestbookk"
];

use W1020\CRUD;

$crud = new CRUD($config);

$crud->setTableName('gb');
if (!empty($_POST)) {
    $crud->ins($_POST);
    header("Location: ?");
}
$table = $crud->get();
//print_r($table);
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>

<table class="table table-success table-striped">

    <?php

        echo "<th>message</th><th>name</th><th>delete</th><th>edit</th>";
    foreach ($table as $value) {
        echo "<tr><td>$value[message]</td><td>$value[name]</td><td><a href='delete.php?id=$value[id]'>❌</a></td><td><a href='update.php?id=$value[id]'>✏️</a></td></tr>";
    }
    ?>
</table>

<form action="?" method="post">
    <textarea class="form-control" name="message">
    </textarea>
    <input class="form-control" type="text" name="name">
    <input class="form-control" type="submit" value="OK">
</form>

</body>
</html>