<?php

$link = mysqli_connect("localhost", "root", "root", "servicevote");
